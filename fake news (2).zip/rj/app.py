from flask import Flask, request, render_template
import pickle

app = Flask(__name__)

# Load the trained model
try:
    with open('D:/rj/model/model.pkl', 'rb') as model_file:
        model, tfidf_vectorizer = pickle.load(model_file)
    print("Model loaded successfully.")
except FileNotFoundError:
    print("Error: Model file 'model/model.pkl' not found.")
except Exception as e:
    print(f"An error occurred while loading the model: {str(e)}")

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    news_text = request.form['news_text']
    vectorized_text = tfidf_vectorizer.transform([news_text])
    prediction = model.predict(vectorized_text)[0]
    result = "Real" if prediction == 1 else "Fake"
    return render_template('index.html', prediction=result)

if __name__ == '__main__':
    app.run(debug=True)
